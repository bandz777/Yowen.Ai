# Meridian FX

One project, one deploy: the dashboard (Vite + React) and its data API
(serverless functions in `/api`) now live together and ship to a single
URL on Vercel's free tier. No separate backend to host, no CORS to
configure.

## Get your free API keys first (5 minutes)

You need these before it'll show real data:

1. **twelvedata.com** → sign up → copy the API key from your dashboard
2. **finnhub.io** → sign up → copy the API key from your dashboard
3. *(optional, for sentiment scoring)* **alphavantage.co/support/#api-key**
4. **console.anthropic.com** → API Keys → create one (this one is billed per use — a briefing costs a fraction of a cent, not free like the others)

## Publish it — easiest path (no terminal beyond copy/paste)

1. Put this folder in a GitHub repo (drag the files into a new repo on
   github.com, or use GitHub Desktop if you'd rather not use git commands).
2. Go to **vercel.com/new**, sign in with GitHub, and import that repo.
3. Vercel auto-detects Vite — leave the build settings as-is.
4. Before clicking Deploy, open **Environment Variables** and add the four
   keys from `.env.local.example` (names must match exactly).
5. Click **Deploy**. In about a minute you get a live URL like
   `meridian-fx-yourname.vercel.app` — that's the site, done.
6. Every time you push a change to GitHub, Vercel redeploys automatically.

## Publish it — fastest path (one terminal command)

```bash
npm install -g vercel
vercel login
cd meridian-fx
vercel          # deploys a preview URL, asks a few setup questions once
vercel --prod   # promotes it to your permanent production URL
```
The first `vercel` run will ask to link/create a project — accept the
defaults. Add your API keys when it prompts, or afterwards at
vercel.com → your project → Settings → Environment Variables.

## Running it locally before you publish

```bash
npm install
cp .env.local.example .env.local   # fill in your keys
npm run dev                        # this runs `vercel dev`
```
Open the URL it prints (usually `http://localhost:3000`). Using
`vercel dev` instead of plain `vite dev` matters — it's what makes the
`/api/*` routes work locally, the same way they will in production.

## After it's live

- Your URL is public — anyone with the link can open the dashboard.
- Custom domain: Vercel → your project → Settings → Domains → add one you own.
- Costs: Vercel Hobby tier is free for personal projects. The only recurring
  cost is Anthropic API usage, and only when someone clicks "Generate briefing."
- If a data panel shows an error, it's almost always a missing/typo'd key —
  check Settings → Environment Variables, fix it, then redeploy.

## What's really running here

- `/api/prices`, `/api/calendar`, `/api/news` — serverless functions that
  call Twelve Data / Finnhub / Alpha Vantage, cached in-memory per warm
  instance to stay inside free-tier rate limits
- `/api/briefing` — same idea, but also calls Claude to write the context
  paragraph; it's a POST so it only runs when someone presses the button
- `src/` — the dashboard UI, unchanged in design, now fetching from `/api/*`
  on the same domain instead of a separate server

See the code comments in `/lib/providers` if you want to swap any data
source out later — each provider is isolated in its own file.
