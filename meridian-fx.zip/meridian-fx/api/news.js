import { cached } from "../lib/cache.js";
import { fetchForexNews } from "../lib/providers/finnhub.js";
import { fetchMacroSentiment } from "../lib/providers/alphaVantage.js";

export default async function handler(req, res) {
  try {
    const { data: news, cached: newsCached, stale: newsStale } = await cached(
      "news",
      15 * 60 * 1000,
      fetchForexNews
    );

    let sentiment = null;
    try {
      const r = await cached("sentiment", 60 * 60 * 1000, fetchMacroSentiment);
      sentiment = r.data;
    } catch {
      sentiment = null;
    }

    res.status(200).json({ news, sentiment, cached: newsCached, stale: newsStale, updatedAt: new Date().toISOString() });
  } catch (err) {
    res.status(502).json({ error: err.message });
  }
}
