import { cached } from "../lib/cache.js";
import { fetchQuotes } from "../lib/providers/twelveData.js";

export default async function handler(req, res) {
  try {
    const { data, cached: fromCache, stale } = await cached("prices", 20_000, fetchQuotes);
    res.status(200).json({ data, cached: fromCache, stale, updatedAt: new Date().toISOString() });
  } catch (err) {
    res.status(502).json({ error: err.message });
  }
}
