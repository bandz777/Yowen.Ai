import { cached } from "../lib/cache.js";
import { fetchQuotes } from "../lib/providers/twelveData.js";
import { fetchEconomicCalendar, fetchForexNews } from "../lib/providers/finnhub.js";
import { fetchMacroSentiment } from "../lib/providers/alphaVantage.js";
import { generateBriefing } from "../lib/providers/anthropic.js";

export default async function handler(req, res) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ error: "Use POST" });
  }

  try {
    const from = new Date().toISOString().slice(0, 10);
    const to = new Date(Date.now() + 14 * 86_400_000).toISOString().slice(0, 10);

    const [pricesResult, calendarResult, newsResult] = await Promise.all([
      cached("prices", 20_000, fetchQuotes),
      cached(`calendar:${from}:${to}`, 60 * 60 * 1000, () => fetchEconomicCalendar(from, to)),
      cached("news", 15 * 60 * 1000, fetchForexNews),
    ]);

    let sentiment = null;
    try {
      const r = await cached("sentiment", 60 * 60 * 1000, fetchMacroSentiment);
      sentiment = r.data;
    } catch {
      sentiment = null;
    }

    const text = await generateBriefing({
      prices: pricesResult.data,
      calendar: calendarResult.data,
      news: newsResult.data,
      sentiment,
    });

    res.status(200).json({ text, generatedAt: new Date().toISOString() });
  } catch (err) {
    res.status(502).json({ error: err.message });
  }
}
