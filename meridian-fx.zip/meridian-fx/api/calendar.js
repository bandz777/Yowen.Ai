import { cached } from "../lib/cache.js";
import { fetchEconomicCalendar } from "../lib/providers/finnhub.js";

function dateRange(days) {
  const from = new Date().toISOString().slice(0, 10);
  const to = new Date(Date.now() + days * 86_400_000).toISOString().slice(0, 10);
  return { from, to };
}

export default async function handler(req, res) {
  try {
    const days = Math.min(Number(req.query.days) || 14, 30);
    const { from, to } = dateRange(days);
    const { data, cached: fromCache, stale } = await cached(
      `calendar:${from}:${to}`,
      60 * 60 * 1000,
      () => fetchEconomicCalendar(from, to)
    );
    res.status(200).json({ data, cached: fromCache, stale, updatedAt: new Date().toISOString() });
  } catch (err) {
    res.status(502).json({ error: err.message });
  }
}
